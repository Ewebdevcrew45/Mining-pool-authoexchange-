<?php

namespace ccxt;

class OrderNotFillable extends InvalidOrder {

}