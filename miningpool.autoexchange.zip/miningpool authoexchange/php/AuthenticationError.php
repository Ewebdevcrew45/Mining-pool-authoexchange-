<?php

namespace ccxt;

class AuthenticationError extends ExchangeError {

}