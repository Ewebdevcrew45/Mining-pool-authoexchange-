<?php

namespace ccxt;

class AddressPending extends InvalidAddress {

}