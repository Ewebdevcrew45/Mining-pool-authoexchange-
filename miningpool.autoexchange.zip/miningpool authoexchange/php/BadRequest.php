<?php

namespace ccxt;

use Exception;

class BadRequest extends ExchangeError {

}
