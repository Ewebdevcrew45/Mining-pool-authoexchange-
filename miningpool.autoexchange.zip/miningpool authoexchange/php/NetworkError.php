<?php

namespace ccxt;

class NetworkError extends BaseError {

}